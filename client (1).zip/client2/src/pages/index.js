import Layout from '@/src/components/Layout';
import React from 'react';

const Index = () => {

  return (
    <>
      <Layout>
        <h1 className="text-2xl text-gray-800 font-light">Dashboard</h1>

      </Layout>
    </>
  );
};

export default Index;
