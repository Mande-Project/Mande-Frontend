export const typeOfUsers = [
  { value: 'worker', label: 'Customer' },
  { value: 'customer', label: 'Worker' },
  // { value: 'ADMINISTRADOR', label: 'Administrador' },
]
