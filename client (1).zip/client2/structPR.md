Name: Carlos Andrés Hernández Agudelo - 2125653

Objective of the pull request:

Added features:


samueltrujillo85@yopmail.com
MandeSamuel2023

customer01922gg@yopmail.com
MandeSamuel2023

customer01939gg@yopmail.com
MandeSamuel2023

customer019399394@yopmail.com
MandeSamuel2023


MandeContra20232

